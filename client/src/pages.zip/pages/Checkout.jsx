import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';

function Checkout() {
  const [addresses, setAddresses]         = useState([]);
  const [selectedAddr, setSelectedAddr]   = useState('');
  const [paymentMethod, setPaymentMethod] = useState('upi');
  const [newAddr, setNewAddr]             = useState({ flat_no: '', building_name: '', city: '', state: '', pincode: '' });
  const [showAddrForm, setShowAddrForm]   = useState(false);
  const [loading, setLoading]             = useState(false);

  const navigate = useNavigate();

  // Always read fresh from localStorage
  const getUserData = () => JSON.parse(localStorage.getItem('user') || '{}');
  const cart  = JSON.parse(localStorage.getItem('cart') || '[]');
  const total = cart.reduce((sum, i) => sum + i.product_price * i.quantity, 0);

  useEffect(() => {
    const userData = getUserData();
    if (userData.id) fetchAddresses(userData.id);
  }, []); // eslint-disable-line

  const fetchAddresses = async (userId) => {
    try {
      const { data } = await API.get(`/address/${userId}`);
      setAddresses(data);
      if (data.length > 0) setSelectedAddr(data[0].address_id);
    } catch (err) {
      console.error('Failed to fetch addresses:', err);
    }
  };

  const addAddress = async () => {
    const userData = getUserData();

    if (!newAddr.city || !newAddr.state || !newAddr.pincode)
      return alert('City, State and Pincode are required!');

    try {
      await API.post('/address', {
        user_id:       userData.id,
        flat_no:       newAddr.flat_no,
        building_name: newAddr.building_name,
        city:          newAddr.city,
        state:         newAddr.state,
        pincode:       newAddr.pincode,
      });
      setShowAddrForm(false);
      setNewAddr({ flat_no: '', building_name: '', city: '', state: '', pincode: '' });
      fetchAddresses(userData.id);
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to add address');
    }
  };

  const handleCheckout = async () => {
    const userData = getUserData();
    if (!selectedAddr) return alert('Please select a delivery address!');
    if (cart.length === 0) return alert('Your cart is empty!');
    setLoading(true);
    try {
      const items = cart.map(i => ({
        product_id: i.product_id,
        quantity:   i.quantity,
        unit_price: i.product_price,
      }));
      const { data: orderData } = await API.post('/orders', { user_id: userData.id, items });
      await API.post('/payment', {
        order_id:       orderData.order_id,
        address_id:     selectedAddr,
        payment_method: paymentMethod,
      });
      localStorage.removeItem('cart');
      alert('🎉 Order placed & payment successful!');
      navigate('/orders');
    } catch (err) {
      alert(err.response?.data?.error || 'Checkout failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <h2 style={{ color: '#1a1a2e' }}>✅ Checkout</h2>

      <div style={styles.section}>
        <h3>🧾 Order Summary</h3>
        {cart.map(i => (
          <div key={i.product_id} style={styles.summaryRow}>
            <span>{i.product_name} × {i.quantity}</span>
            <span>₹{(i.product_price * i.quantity).toLocaleString()}</span>
          </div>
        ))}
        <div style={{ ...styles.summaryRow, fontWeight: 'bold', borderTop: '1px solid #eee', paddingTop: '8px', marginTop: '8px' }}>
          <span>Total</span>
          <span style={{ color: '#e74c3c' }}>₹{total.toLocaleString()}</span>
        </div>
      </div>

      <div style={styles.section}>
        <h3>📍 Delivery Address</h3>
        {addresses.length === 0 && !showAddrForm && (
          <p style={{ color: '#999', fontSize: '14px' }}>No addresses found. Add one below.</p>
        )}
        {addresses.map(a => (
          <label key={a.address_id} style={styles.addrOption}>
            <input type="radio" name="address" value={a.address_id}
              checked={selectedAddr === a.address_id}
              onChange={() => setSelectedAddr(a.address_id)} />
            &nbsp; {a.flat_no && `${a.flat_no}, `}
            {a.building_name && `${a.building_name}, `}
            {a.city}, {a.state} - {a.pincode}
          </label>
        ))}
        <button style={styles.addAddrBtn} onClick={() => setShowAddrForm(!showAddrForm)}>
          {showAddrForm ? '✕ Cancel' : '+ Add New Address'}
        </button>
        {showAddrForm && (
          <div style={{ marginTop: '12px' }}>
            {[
              { key: 'flat_no',       placeholder: 'Flat No (optional)' },
              { key: 'building_name', placeholder: 'Building Name (optional)' },
              { key: 'city',          placeholder: 'City *' },
              { key: 'state',         placeholder: 'State *' },
              { key: 'pincode',       placeholder: 'Pincode *' },
            ].map(({ key, placeholder }) => (
              <input key={key} style={styles.input} placeholder={placeholder}
                value={newAddr[key]}
                onChange={e => setNewAddr({ ...newAddr, [key]: e.target.value })} />
            ))}
            <button style={styles.saveAddrBtn} onClick={addAddress}>Save Address</button>
          </div>
        )}
      </div>

      <div style={styles.section}>
        <h3>💳 Payment Method</h3>
        {[
          { value: 'upi',         label: '📱 UPI' },
          { value: 'credit_card', label: '💳 Credit Card' },
          { value: 'debit_card',  label: '💳 Debit Card' },
          { value: 'cash',        label: '💵 Cash on Delivery' },
        ].map(({ value, label }) => (
          <label key={value} style={styles.payOption}>
            <input type="radio" name="payment" value={value}
              checked={paymentMethod === value}
              onChange={() => setPaymentMethod(value)} />
            &nbsp; {label}
          </label>
        ))}
      </div>

      <button style={{ ...styles.placeBtn, opacity: loading ? 0.7 : 1 }}
        onClick={handleCheckout} disabled={loading}>
        {loading ? '⏳ Placing Order...' : '🛒 Place Order & Pay'}
      </button>
    </div>
  );
}

const styles = {
  section:     { background: '#fff', borderRadius: '8px', padding: '20px',
                 marginBottom: '16px', boxShadow: '0 1px 6px rgba(0,0,0,0.07)' },
  summaryRow:  { display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '15px' },
  addrOption:  { display: 'block', padding: '8px 0', cursor: 'pointer', fontSize: '14px' },
  addAddrBtn:  { marginTop: '10px', background: 'none', border: '1px dashed #1a1a2e',
                 padding: '6px 14px', borderRadius: '4px', cursor: 'pointer', color: '#1a1a2e' },
  saveAddrBtn: { background: '#27ae60', color: 'white', border: 'none', padding: '8px 16px',
                 borderRadius: '4px', cursor: 'pointer', marginTop: '8px' },
  input:       { display: 'block', width: '100%', padding: '8px', margin: '4px 0',
                 border: '1px solid #ddd', borderRadius: '4px', fontSize: '14px', boxSizing: 'border-box' },
  payOption:   { display: 'block', padding: '8px 0', cursor: 'pointer', fontSize: '14px' },
  placeBtn:    { width: '100%', padding: '14px', background: '#e74c3c', color: 'white',
                 border: 'none', borderRadius: '6px', fontSize: '16px', cursor: 'pointer' },
};

export default Checkout;