import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import API from '../api/axios';

function Products() {
  const [products, setProducts] = useState([]);
  const [search, setSearch]     = useState('');
  const [loading, setLoading]   = useState(true);
  const [cartCount, setCartCount] = useState(0); // ← NEW
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
    updateCartCount(); // ← NEW
  }, []);

  const updateCartCount = () => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    setCartCount(cart.length);
  };

  const fetchProducts = async () => {
    try {
      const { data } = await API.get('/products');
      setProducts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (e) => {
    const q = e.target.value;
    setSearch(q);
    if (q.trim() === '') return fetchProducts();
    try {
      const token = localStorage.getItem('token');
      if (token) {
        const { data } = await API.post('/products/search', { query: q });
        setProducts(data);
      } else {
        const { data } = await API.get('/products');
        setProducts(data.filter(p => p.product_name.toLowerCase().includes(q.toLowerCase())));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const addToCart = (product) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const existing = cart.find(i => i.product_id === product.product_id);
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({ ...product, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount(); // ← UPDATE COUNT after adding
    alert(`✅ "${product.product_name}" added to cart!`);
  };

  return (
    <div>
      <h2 style={{ color: '#1a1a2e' }}>🛍️ Products</h2>
      <input
        style={styles.searchBox}
        type="text"
        placeholder="🔍 Search products..."
        value={search}
        onChange={handleSearch}
      />
      {loading ? (
        <p>Loading products...</p>
      ) : products.length === 0 ? (
        <p>No products found.</p>
      ) : (
        <div style={styles.grid}>
          {products.map(p => (
            <div key={p.product_id} style={styles.card}>
              <div style={styles.emoji}>📦</div>
              <h3 style={styles.name}>{p.product_name}</h3>
              <p style={styles.price}>₹{parseFloat(p.product_price).toLocaleString()}</p>
              <p style={styles.stock}>
                {p.stock > 0 ? `✅ In Stock (${p.stock})` : '❌ Out of Stock'}
              </p>
              <button
                style={{ ...styles.btn, opacity: p.stock === 0 ? 0.5 : 1 }}
                onClick={() => addToCart(p)}
                disabled={p.stock === 0}
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Floating Cart Button — only shows when cart has items */}
      {cartCount > 0 && (
        <button style={styles.cartBtn} onClick={() => navigate('/cart')}>
          🛒 View Cart ({cartCount})
        </button>
      )}
    </div>
  );
}

const styles = {
  searchBox: { padding: '10px 16px', width: '100%', maxWidth: '400px', fontSize: '15px',
               border: '1px solid #ddd', borderRadius: '6px', marginBottom: '24px', boxSizing: 'border-box' },
  grid:      { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '20px' },
  card:      { background: '#fff', borderRadius: '10px', padding: '20px', textAlign: 'center',
               boxShadow: '0 2px 10px rgba(0,0,0,0.08)' },
  emoji:     { fontSize: '40px', marginBottom: '8px' },
  name:      { fontSize: '16px', fontWeight: '600', color: '#1a1a2e', margin: '8px 0' },
  price:     { fontSize: '20px', color: '#e74c3c', fontWeight: 'bold' },
  stock:     { fontSize: '13px', color: '#555', marginBottom: '12px' },
  btn:       { background: '#1a1a2e', color: 'white', border: 'none', padding: '8px 20px',
               borderRadius: '4px', cursor: 'pointer', width: '100%' },
  cartBtn:   { position: 'fixed', bottom: '30px', right: '30px', background: '#f0a500',
               color: 'white', border: 'none', padding: '14px 24px', borderRadius: '30px',
               fontSize: '16px', cursor: 'pointer', boxShadow: '0 4px 12px rgba(0,0,0,0.2)' },
};

export default Products;