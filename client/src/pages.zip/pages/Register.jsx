import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import API from '../api/axios';

function Register() {
  const [form, setForm]       = useState({ username: '', email: '', password: '' });
  const [error, setError]     = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await API.post('/auth/register', form);
      setSuccess('Registered successfully! Redirecting to login...');
      setTimeout(() => navigate('/login'), 2000);
    } catch (err) {
      setError(err.response?.data?.error || 'Registration failed');
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>📝 Create Account</h2>
        {error   && <p style={styles.error}>{error}</p>}
        {success && <p style={styles.success}>{success}</p>}
        <form onSubmit={handleSubmit}>
          <input
            style={styles.input} type="text" name="username"
            placeholder="Username" value={form.username} onChange={handleChange} required
          />
          <input
            style={styles.input} type="email" name="email"
            placeholder="Email" value={form.email} onChange={handleChange} required
          />
          <input
            style={styles.input} type="password" name="password"
            placeholder="Password (min 6 chars)" value={form.password}
            onChange={handleChange} minLength={6} required
          />
          <button style={styles.btn} type="submit">Register</button>
        </form>
        <p style={styles.linkText}>
          Already have an account? <Link to="/login">Login here</Link>
        </p>
      </div>
    </div>
  );
}

const styles = {
  container: { display: 'flex', justifyContent: 'center', paddingTop: '60px' },
  card:      { background: '#fff', padding: '40px', borderRadius: '8px',
               boxShadow: '0 2px 15px rgba(0,0,0,0.1)', width: '360px' },
  title:     { textAlign: 'center', marginBottom: '24px', color: '#1a1a2e' },
  input:     { display: 'block', width: '100%', padding: '10px', marginBottom: '16px',
               border: '1px solid #ddd', borderRadius: '4px', fontSize: '14px', boxSizing: 'border-box' },
  btn:       { width: '100%', padding: '12px', background: '#27ae60', color: 'white',
               border: 'none', borderRadius: '4px', fontSize: '16px', cursor: 'pointer' },
  error:     { color: 'red', marginBottom: '12px', textAlign: 'center' },
  success:   { color: 'green', marginBottom: '12px', textAlign: 'center' },
  linkText:  { textAlign: 'center', marginTop: '16px', fontSize: '14px' },
};

export default Register;