import { useState, useEffect } from 'react';
import API from '../api/axios';

const STATUS_COLORS = {
  pending:   '#f0a500',
  confirmed: '#3498db',
  shipped:   '#9b59b6',
  delivered: '#27ae60',
  cancelled: '#e74c3c',
};

function Orders() {
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const { data } = await API.get(`/orders/${user.id}`);
        setOrders(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, [user.id]); 

  if (loading) return <p>Loading orders...</p>;

  if (orders.length === 0)
    return <div style={{ textAlign: 'center', paddingTop: '60px' }}>
      <h2>📦 No orders yet!</h2>
    </div>;

  return (
    <div style={{ maxWidth: '750px', margin: '0 auto' }}>
      <h2 style={{ color: '#1a1a2e' }}>📦 My Orders</h2>
      {orders.map(order => (
        <div key={order.order_id} style={styles.card}>
          <div style={styles.header}>
            <span><strong>Order #{order.order_id}</strong></span>
            <span style={{ ...styles.badge, background: STATUS_COLORS[order.status] || '#999' }}>
              {order.status.toUpperCase()}
            </span>
          </div>
          <p style={styles.date}>🗓️ {new Date(order.created_at).toLocaleDateString('en-IN', { dateStyle: 'long' })}</p>
          <table style={styles.table}>
            <thead>
              <tr>
                <th style={styles.th}>Product</th>
                <th style={styles.th}>Qty</th>
                <th style={styles.th}>Price</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map(item => (
                <tr key={item.item_id}>
                  <td style={styles.td}>{item.product_name}</td>
                  <td style={styles.td}>{item.quantity}</td>
                  <td style={styles.td}>₹{parseFloat(item.unit_price).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={styles.total}>
            Total: <strong style={{ color: '#e74c3c' }}>₹{parseFloat(order.total_amount).toLocaleString()}</strong>
          </div>
        </div>
      ))}
    </div>
  );
}

const styles = {
  card:   { background: '#fff', borderRadius: '10px', padding: '20px',
            marginBottom: '16px', boxShadow: '0 2px 10px rgba(0,0,0,0.08)' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  badge:  { color: 'white', padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 'bold' },
  date:   { color: '#666', fontSize: '13px', marginTop: '6px' },
  table:  { width: '100%', borderCollapse: 'collapse', marginTop: '12px' },
  th:     { textAlign: 'left', padding: '8px', background: '#f5f5f5', fontSize: '13px' },
  td:     { padding: '8px', borderBottom: '1px solid #f0f0f0', fontSize: '14px' },
  total:  { textAlign: 'right', marginTop: '12px', fontSize: '16px' },
};

export default Orders;