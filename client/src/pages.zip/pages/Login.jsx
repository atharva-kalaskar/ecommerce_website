import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import API from '../api/axios';

function Login() {
  const [form, setForm]     = useState({ email: '', password: '' });
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { data } = await API.post('/auth/login', form);
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      navigate('/products');
    } catch (err) {
      setError(err.response?.data?.error || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>🔐 Login</h2>
        {error && <p style={styles.error}>{error}</p>}
        <form onSubmit={handleSubmit}>
          <input
            style={styles.input} type="email" name="email"
            placeholder="Email" value={form.email} onChange={handleChange} required
          />
          <input
            style={styles.input} type="password" name="password"
            placeholder="Password" value={form.password} onChange={handleChange} required
          />
          <button style={styles.btn} type="submit" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>
        <p style={styles.link}>
          Don't have an account? <Link to="/register">Register here</Link>
        </p>
      </div>
    </div>
  );
}

const styles = {
  container: { display: 'flex', justifyContent: 'center', paddingTop: '60px' },
  card:      { background: '#fff', padding: '40px', borderRadius: '8px',
               boxShadow: '0 2px 15px rgba(0,0,0,0.1)', width: '360px' },
  title:     { textAlign: 'center', marginBottom: '24px', color: '#1a1a2e' },
  input:     { display: 'block', width: '100%', padding: '10px', marginBottom: '16px',
               border: '1px solid #ddd', borderRadius: '4px', fontSize: '14px', boxSizing: 'border-box' },
  btn:       { width: '100%', padding: '12px', background: '#1a1a2e', color: 'white',
               border: 'none', borderRadius: '4px', fontSize: '16px', cursor: 'pointer' },
  error:     { color: 'red', marginBottom: '12px', textAlign: 'center' },
  link:      { textAlign: 'center', marginTop: '16px', fontSize: '14px' },
};

export default Login;