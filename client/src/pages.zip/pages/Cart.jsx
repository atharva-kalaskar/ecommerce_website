import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function Cart() {
  const [cart, setCart] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setCart(JSON.parse(localStorage.getItem('cart') || '[]'));
  }, []);

  const updateQty = (productId, delta) => {
    const updated = cart.map(item =>
      item.product_id === productId
        ? { ...item, quantity: Math.max(1, item.quantity + delta) }
        : item
    );
    setCart(updated);
    localStorage.setItem('cart', JSON.stringify(updated));
  };

  const removeItem = (productId) => {
    const updated = cart.filter(i => i.product_id !== productId);
    setCart(updated);
    localStorage.setItem('cart', JSON.stringify(updated));
  };

  const total = cart.reduce((sum, i) => sum + i.product_price * i.quantity, 0);

  if (cart.length === 0)
    return (
      <div style={{ textAlign: 'center', paddingTop: '60px' }}>
        <h2>🛒 Your cart is empty!</h2>
        <button style={styles.shopBtn} onClick={() => navigate('/products')}>
          Continue Shopping
        </button>
      </div>
    );

  return (
    <div style={{ maxWidth: '700px', margin: '0 auto' }}>
      <h2 style={{ color: '#1a1a2e' }}>🛒 Your Cart</h2>
      {cart.map(item => (
        <div key={item.product_id} style={styles.row}>
          <div>
            <p style={styles.name}>{item.product_name}</p>
            <p style={styles.price}>₹{parseFloat(item.product_price).toLocaleString()}</p>
          </div>
          <div style={styles.qtyRow}>
            <button style={styles.qtyBtn} onClick={() => updateQty(item.product_id, -1)}>−</button>
            <span style={styles.qty}>{item.quantity}</span>
            <button style={styles.qtyBtn} onClick={() => updateQty(item.product_id, +1)}>+</button>
            <button style={styles.removeBtn} onClick={() => removeItem(item.product_id)}>🗑️</button>
          </div>
        </div>
      ))}
      <div style={styles.totalRow}>
        <strong>Total:</strong>
        <strong style={{ color: '#e74c3c' }}>₹{total.toLocaleString()}</strong>
      </div>
      <button style={styles.checkoutBtn} onClick={() => navigate('/checkout')}>
        Proceed to Checkout →
      </button>
    </div>
  );
}

const styles = {
  row:         { display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                 background: '#fff', padding: '16px 20px', borderRadius: '8px',
                 marginBottom: '12px', boxShadow: '0 1px 6px rgba(0,0,0,0.07)' },
  name:        { fontWeight: '600', color: '#1a1a2e', margin: 0 },
  price:       { color: '#e74c3c', margin: '4px 0 0' },
  qtyRow:      { display: 'flex', alignItems: 'center', gap: '10px' },
  qtyBtn:      { width: '30px', height: '30px', border: '1px solid #ddd',
                 background: '#f5f5f5', cursor: 'pointer', borderRadius: '4px', fontSize: '18px' },
  qty:         { fontSize: '16px', fontWeight: 'bold', minWidth: '24px', textAlign: 'center' },
  removeBtn:   { background: 'none', border: 'none', cursor: 'pointer', fontSize: '18px' },
  totalRow:    { display: 'flex', justifyContent: 'space-between', fontSize: '20px',
                 padding: '16px 0', borderTop: '2px solid #eee', marginTop: '8px' },
  checkoutBtn: { width: '100%', padding: '14px', background: '#27ae60', color: 'white',
                 border: 'none', borderRadius: '6px', fontSize: '16px', cursor: 'pointer',
                 marginTop: '12px' },
  shopBtn:     { padding: '10px 24px', background: '#1a1a2e', color: 'white', border: 'none',
                 borderRadius: '6px', fontSize: '15px', cursor: 'pointer', marginTop: '16px' },
};

export default Cart;